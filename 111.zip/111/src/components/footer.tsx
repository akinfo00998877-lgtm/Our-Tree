'use client';

import Link from 'next/link';
import { TreeDeciduous, Heart, Globe } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-r from-primary/5 via-coral/5 to-gold/5 border-t border-primary/10 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-teal flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
              <TreeDeciduous className="h-4 w-4 text-white" />
            </div>
            <span className="text-lg font-semibold">
              <span className="teal-text">Cousin</span>
              <span className="rainbow-text">Tree</span>
            </span>
          </Link>

          {/* Copyright */}
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Made with</span>
            <Heart className="h-4 w-4 text-coral fill-coral animate-pulse" />
            <span>for the family</span>
          </div>

          {/* Links */}
          <div className="flex items-center gap-6 text-sm">
            <Link href="/" className="text-muted-foreground hover:text-primary transition-colors">
              Home
            </Link>
            <Link href="/tree" className="text-muted-foreground hover:text-primary transition-colors">
              Tree
            </Link>
            <Link href="/cousins" className="text-muted-foreground hover:text-primary transition-colors">
              Cousins
            </Link>
            <Link href="/gallery" className="text-muted-foreground hover:text-primary transition-colors">
              Gallery
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
