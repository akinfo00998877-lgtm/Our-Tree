import { NextResponse } from 'next/server';
import { deleteSession, getSessionToken } from '@/lib/auth';

export async function POST() {
  try {
    const token = await getSessionToken();
    if (token) {
      await deleteSession(token);
    }
    
    const response = NextResponse.json({ success: true });
    response.cookies.delete('admin_token');
    
    return response;
  } catch (error) {
    console.error('Logout error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
