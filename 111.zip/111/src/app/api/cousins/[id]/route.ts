import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { isAuthenticated } from '@/lib/auth';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const cousin = await db.cousin.findUnique({
      where: { id },
    });
    
    if (!cousin) {
      return NextResponse.json(
        { error: 'Cousin not found' },
        { status: 404 }
      );
    }
    
    return NextResponse.json(cousin);
  } catch (error) {
    console.error('Get cousin error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch cousin' },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authenticated = await isAuthenticated();
    if (!authenticated) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    const body = await request.json();
    const { name, photo, relation, description, parentIds, generation, order } = body;
    
    const cousin = await db.cousin.update({
      where: { id },
      data: {
        name,
        photo: photo || null,
        relation,
        description: description || null,
        parentIds: parentIds || null,
        generation: generation || 1,
        order: order || 0,
      },
    });
    
    return NextResponse.json(cousin);
  } catch (error) {
    console.error('Update cousin error:', error);
    return NextResponse.json(
      { error: 'Failed to update cousin' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authenticated = await isAuthenticated();
    if (!authenticated) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const { id } = await params;
    await db.cousin.delete({
      where: { id },
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Delete cousin error:', error);
    return NextResponse.json(
      { error: 'Failed to delete cousin' },
      { status: 500 }
    );
  }
}
