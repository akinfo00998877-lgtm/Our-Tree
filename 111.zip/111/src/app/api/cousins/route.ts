import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { isAuthenticated } from '@/lib/auth';

export async function GET() {
  try {
    const cousins = await db.cousin.findMany({
      orderBy: [{ generation: 'asc' }, { order: 'asc' }],
    });
    return NextResponse.json(cousins);
  } catch (error) {
    console.error('Get cousins error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch cousins' },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const authenticated = await isAuthenticated();
    if (!authenticated) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      );
    }
    
    const body = await request.json();
    const { name, photo, relation, description, parentIds, generation, order } = body;
    
    if (!name || !relation) {
      return NextResponse.json(
        { error: 'Name and relation are required' },
        { status: 400 }
      );
    }
    
    const cousin = await db.cousin.create({
      data: {
        name,
        photo: photo || null,
        relation,
        description: description || null,
        parentIds: parentIds || null,
        generation: generation || 1,
        order: order || 0,
      },
    });
    
    return NextResponse.json(cousin);
  } catch (error) {
    console.error('Create cousin error:', error);
    return NextResponse.json(
      { error: 'Failed to create cousin' },
      { status: 500 }
    );
  }
}
