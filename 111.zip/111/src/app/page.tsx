'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TreeDeciduous, Users, Image, Heart, ArrowRight, Star, Sparkles, Globe } from 'lucide-react';
import { useEffect, useState } from 'react';

interface Cousin {
  id: string;
  name: string;
  photo: string | null;
  relation: string;
  description: string | null;
}

interface GalleryPhoto {
  id: string;
  url: string;
  caption: string | null;
}

export default function HomePage() {
  const [cousins, setCousins] = useState<Cousin[]>([]);
  const [photos, setPhotos] = useState<GalleryPhoto[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [cousinsRes, photosRes] = await Promise.all([
          fetch('/api/cousins'),
          fetch('/api/gallery'),
        ]);
        const cousinsData = await cousinsRes.json();
        const photosData = await photosRes.json();
        setCousins(cousinsData);
        setPhotos(photosData);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const featuredCousins = cousins.slice(0, 4);
  const featuredPhotos = photos.slice(0, 4);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Animated background gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-coral/10" />
        
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="decorative-circle w-96 h-96 bg-primary/20 top-0 left-1/4 animate-float" />
          <div className="decorative-circle w-80 h-80 bg-coral/20 bottom-1/4 right-1/4 animate-float" style={{ animationDelay: '1s' }} />
          <div className="decorative-circle w-64 h-64 bg-gold/20 top-1/3 right-1/3 animate-float" style={{ animationDelay: '2s' }} />
        </div>

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          {/* Badge */}
          <Badge 
            variant="secondary" 
            className="mb-6 px-4 py-2 animate-fadeIn bg-gradient-to-r from-primary/10 to-coral/10 border-primary/20"
          >
            <Sparkles className="h-3.5 w-3.5 mr-2 text-gold" />
            <span className="text-primary font-medium">Family Connections Matter</span>
          </Badge>

          {/* Main Title */}
          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fadeIn">
            <span className="teal-text">Cousin</span>
            <span className="rainbow-text">Tree</span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl mx-auto animate-fadeIn" style={{ animationDelay: '0.1s' }}>
            Connect with your family, explore your roots, and celebrate the bonds that make us who we are.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fadeIn" style={{ animationDelay: '0.2s' }}>
            <Link href="/tree">
              <Button size="lg" className="gap-2 btn-gradient text-white shadow-lg">
                <TreeDeciduous className="h-5 w-5" />
                Explore Family Tree
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/cousins">
              <Button size="lg" variant="outline" className="gap-2 border-primary/30 hover:border-primary hover:bg-primary/5">
                <Users className="h-5 w-5 text-primary" />
                Meet the Cousins
              </Button>
            </Link>
          </div>

          {/* Stats */}
          <div className="flex items-center justify-center gap-8 mt-12 animate-fadeIn" style={{ animationDelay: '0.3s' }}>
            <div className="text-center group">
              <div className="text-4xl font-bold teal-text group-hover:scale-110 transition-transform">{cousins.length}</div>
              <div className="text-sm text-muted-foreground">Cousins</div>
            </div>
            <div className="w-px h-12 bg-gradient-to-b from-transparent via-primary/30 to-transparent" />
            <div className="text-center group">
              <div className="text-4xl font-bold rainbow-text group-hover:scale-110 transition-transform">{photos.length}</div>
              <div className="text-sm text-muted-foreground">Memories</div>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-primary/40 flex items-start justify-center p-1.5">
            <div className="w-1.5 h-3 bg-gradient-to-b from-primary to-coral rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 section-gradient">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-4 border-gold/30 bg-gold/5">
              <Star className="h-3 w-3 mr-2 text-gold" />
              Features
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything <span className="rainbow-text">Family</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Discover, connect, and celebrate with your extended family
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="card-hover bg-gradient-to-br from-card to-primary/5 border-primary/10">
              <CardHeader>
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-teal flex items-center justify-center mb-3 shadow-lg">
                  <TreeDeciduous className="h-7 w-7 text-white" />
                </div>
                <CardTitle className="text-xl">Family Tree</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Visualize your family connections with our interactive family tree. See how everyone is related.
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover bg-gradient-to-br from-card to-coral/5 border-coral/10">
              <CardHeader>
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-coral to-gold flex items-center justify-center mb-3 shadow-lg">
                  <Users className="h-7 w-7 text-white" />
                </div>
                <CardTitle className="text-xl">Cousin Profiles</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Learn more about each cousin with detailed profiles, photos, and personal descriptions.
                </p>
              </CardContent>
            </Card>

            <Card className="card-hover bg-gradient-to-br from-card to-gold/5 border-gold/10">
              <CardHeader>
                <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-gold to-primary flex items-center justify-center mb-3 shadow-lg">
                  <Image className="h-7 w-7 text-white" />
                </div>
                <CardTitle className="text-xl">Memory Gallery</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Browse through precious family moments captured in photos and shared memories.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Cousins */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-12 flex-wrap gap-4">
            <div>
              <Badge variant="outline" className="mb-2 border-primary/20">
                <Users className="h-3 w-3 mr-2 text-primary" />
                Family Members
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold">
                Meet the <span className="rainbow-text">Cousins</span>
              </h2>
              <p className="text-muted-foreground mt-2">Get to know your extended family</p>
            </div>
            <Link href="/cousins">
              <Button variant="outline" className="gap-2 border-primary/20 hover:border-primary hover:bg-primary/5">
                View All <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <Card key={i} className="overflow-hidden">
                  <div className="aspect-square bg-muted animate-pulse" />
                  <CardContent className="p-4">
                    <div className="h-4 bg-muted rounded animate-pulse mb-2" />
                    <div className="h-3 bg-muted rounded animate-pulse w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : featuredCousins.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {featuredCousins.map((cousin, index) => (
                <Link key={cousin.id} href={`/cousins`}>
                  <Card 
                    className="overflow-hidden card-hover cursor-pointer animate-fadeIn group" 
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="aspect-square bg-gradient-to-br from-primary/20 via-coral/10 to-gold/20 flex items-center justify-center overflow-hidden relative">
                      {cousin.photo ? (
                        <img
                          src={cousin.photo}
                          alt={cousin.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                      ) : (
                        <Users className="h-16 w-16 text-primary/40 group-hover:scale-110 transition-transform" />
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-primary/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold truncate group-hover:text-primary transition-colors">{cousin.name}</h3>
                      <Badge variant="secondary" className="mt-1 text-xs">
                        {cousin.relation}
                      </Badge>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center max-w-md mx-auto bg-gradient-to-br from-card to-primary/5">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-primary/50" />
              </div>
              <p className="text-muted-foreground">No cousins added yet. Check back soon!</p>
            </Card>
          )}
        </div>
      </section>

      {/* Featured Gallery */}
      <section className="py-20 px-4 section-gradient">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-12 flex-wrap gap-4">
            <div>
              <Badge variant="outline" className="mb-2 border-gold/20 bg-gold/5">
                <Image className="h-3 w-3 mr-2 text-gold" />
                Photo Gallery
              </Badge>
              <h2 className="text-3xl md:text-4xl font-bold">
                Family <span className="rainbow-text">Memories</span>
              </h2>
              <p className="text-muted-foreground mt-2">Cherished moments captured together</p>
            </div>
            <Link href="/gallery">
              <Button variant="outline" className="gap-2 border-gold/20 hover:border-gold hover:bg-gold/5">
                View Gallery <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="aspect-square bg-muted animate-pulse rounded-lg" />
              ))}
            </div>
          ) : featuredPhotos.length > 0 ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {featuredPhotos.map((photo, index) => (
                <div
                  key={photo.id}
                  className="aspect-square rounded-xl overflow-hidden card-hover cursor-pointer animate-fadeIn group relative"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <img
                    src={photo.url}
                    alt={photo.caption || 'Family photo'}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-coral/50 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  {photo.caption && (
                    <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                      <p className="text-white text-sm truncate">{photo.caption}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center max-w-md mx-auto bg-gradient-to-br from-card to-gold/5">
              <div className="w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-4">
                <Image className="h-8 w-8 text-gold/50" />
              </div>
              <p className="text-muted-foreground">No photos yet. Check back soon!</p>
            </Card>
          )}
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <Card className="p-8 md:p-12 bg-gradient-to-br from-primary/10 via-coral/5 to-gold/10 border-primary/20 relative overflow-hidden">
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-32 h-32 bg-primary/10 rounded-full blur-2xl" />
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-coral/10 rounded-full blur-2xl" />
            
            <div className="relative z-10">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-coral to-gold flex items-center justify-center mx-auto mb-6 shadow-lg">
                <Heart className="h-8 w-8 text-white fill-white" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">
                Family is <span className="rainbow-text">Forever</span>
              </h2>
              <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
                Explore your family tree, connect with cousins, and celebrate the bonds that make us who we are. 
                Every branch tells a story, every leaf a memory.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Link href="/tree">
                  <Button size="lg" className="gap-2 btn-gradient text-white shadow-lg">
                    <TreeDeciduous className="h-5 w-5" />
                    Start Exploring
                  </Button>
                </Link>
              </div>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}
