'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Users, TreeDeciduous, ZoomIn, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface Cousin {
  id: string;
  name: string;
  photo: string | null;
  relation: string;
  description: string | null;
  generation: number;
  parentIds: string | null;
}

export default function TreePage() {
  const [cousins, setCousins] = useState<Cousin[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCousin, setSelectedCousin] = useState<Cousin | null>(null);

  useEffect(() => {
    const fetchCousins = async () => {
      try {
        const res = await fetch('/api/cousins');
        const data = await res.json();
        setCousins(data);
      } catch (error) {
        console.error('Error fetching cousins:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchCousins();
  }, []);

  // Group cousins by generation
  const generations = cousins.reduce((acc, cousin) => {
    const gen = cousin.generation;
    if (!acc[gen]) acc[gen] = [];
    acc[gen].push(cousin);
    return acc;
  }, {} as Record<number, Cousin[]>);

  const sortedGenerations = Object.keys(generations)
    .map(Number)
    .sort((a, b) => a - b);

  const generationColors = [
    'from-primary to-teal',
    'from-teal to-coral',
    'from-coral to-gold',
    'from-gold to-primary',
    'from-primary to-coral',
  ];

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4 border-primary/20 bg-primary/5 px-4 py-1">
            <TreeDeciduous className="h-3.5 w-3.5 mr-2 text-primary" />
            Family Connections
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Our <span className="rainbow-text">Family Tree</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore the branches of our family and discover how everyone is connected
          </p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
          </div>
        ) : cousins.length === 0 ? (
          <Card className="p-12 text-center max-w-md mx-auto bg-gradient-to-br from-card to-primary/5">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-primary/20 to-coral/20 flex items-center justify-center mx-auto mb-4">
              <Users className="h-10 w-10 text-primary/50" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No Family Members Yet</h3>
            <p className="text-muted-foreground">
              The family tree is being built. Check back soon!
            </p>
          </Card>
        ) : (
          <div className="space-y-8">
            {sortedGenerations.map((gen, genIndex) => (
              <motion.div
                key={gen}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: genIndex * 0.2 }}
                className="relative"
              >
                {/* Generation Label */}
                <div className="flex items-center justify-center mb-6">
                  <Badge
                    className={`px-4 py-2 bg-gradient-to-r ${generationColors[genIndex % generationColors.length]} text-white shadow-lg`}
                  >
                    Generation {gen}
                  </Badge>
                </div>

                {/* Connection Line Above */}
                {genIndex > 0 && (
                  <div className="absolute -top-4 left-1/2 w-0.5 h-4 bg-gradient-to-b from-gold to-primary" />
                )}

                {/* Cousins Grid */}
                <div className="flex flex-wrap justify-center gap-4">
                  {generations[gen].map((cousin, cousinIndex) => (
                    <motion.div
                      key={cousin.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: genIndex * 0.2 + cousinIndex * 0.1 }}
                      className="relative group"
                    >
                      {/* Connection Line */}
                      <div className="absolute -top-4 left-1/2 w-0.5 h-4 bg-gradient-to-b from-gold to-primary opacity-0 group-hover:opacity-100 transition-opacity" />
                      
                      <Card
                        className="cursor-pointer overflow-hidden transition-all duration-300 hover:shadow-2xl hover:scale-105"
                        onClick={() => setSelectedCousin(cousin)}
                      >
                        <div className="w-32 md:w-40">
                          {/* Photo */}
                          <div className="aspect-square bg-gradient-to-br from-primary/10 via-coral/10 to-gold/10 flex items-center justify-center overflow-hidden relative">
                            {cousin.photo ? (
                              <img
                                src={cousin.photo}
                                alt={cousin.name}
                                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                              />
                            ) : (
                              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-coral/20 flex items-center justify-center">
                                <Users className="h-8 w-8 text-primary/40" />
                              </div>
                            )}
                            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <div className="w-8 h-8 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center">
                                <ZoomIn className="h-4 w-4 text-primary" />
                              </div>
                            </div>
                          </div>

                          {/* Info */}
                          <CardContent className="p-3 text-center bg-gradient-to-b from-card to-primary/5">
                            <h3 className="font-semibold text-sm truncate group-hover:text-primary transition-colors">{cousin.name}</h3>
                            <p className="text-xs text-muted-foreground truncate">{cousin.relation}</p>
                          </CardContent>
                        </div>
                      </Card>
                    </motion.div>
                  ))}
                </div>

                {/* Connection Line Below */}
                {genIndex < sortedGenerations.length - 1 && (
                  <div className="flex justify-center mt-4">
                    <div className="w-0.5 h-8 bg-gradient-to-b from-primary to-gold" />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        )}

        {/* Selected Cousin Modal */}
        <AnimatePresence>
          {selectedCousin && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-md p-4"
              onClick={() => setSelectedCousin(null)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
              >
                <Card className="max-w-sm w-full overflow-hidden shadow-2xl">
                  <div className="aspect-square bg-gradient-to-br from-primary/10 via-coral/10 to-gold/10 flex items-center justify-center relative">
                    {selectedCousin.photo ? (
                      <img
                        src={selectedCousin.photo}
                        alt={selectedCousin.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary/20 to-coral/20 flex items-center justify-center">
                        <Users className="h-12 w-12 text-primary/40" />
                      </div>
                    )}
                    <button
                      className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                      onClick={() => setSelectedCousin(null)}
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                  <CardContent className="p-6 bg-gradient-to-b from-card to-primary/5">
                    <h2 className="text-2xl font-bold mb-2 teal-text">{selectedCousin.name}</h2>
                    <Badge className="bg-gradient-to-r from-primary to-teal text-white mb-4">
                      {selectedCousin.relation}
                    </Badge>
                    {selectedCousin.description && (
                      <p className="text-muted-foreground">{selectedCousin.description}</p>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
