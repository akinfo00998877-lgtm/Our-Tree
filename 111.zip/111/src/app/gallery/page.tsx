'use client';

import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Image, Search, X, ZoomIn, Sparkles } from 'lucide-react';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface GalleryPhoto {
  id: string;
  url: string;
  caption: string | null;
  category: string | null;
}

export default function GalleryPage() {
  const [photos, setPhotos] = useState<GalleryPhoto[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPhoto, setSelectedPhoto] = useState<GalleryPhoto | null>(null);

  useEffect(() => {
    const fetchPhotos = async () => {
      try {
        const res = await fetch('/api/gallery');
        const data = await res.json();
        setPhotos(data);
      } catch (error) {
        console.error('Error fetching photos:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchPhotos();
  }, []);

  // Filter photos
  const filteredPhotos = photos.filter(photo => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      photo.caption?.toLowerCase().includes(query) ||
      photo.category?.toLowerCase().includes(query)
    );
  });

  const overlayGradients = [
    'from-primary/40 via-transparent to-transparent',
    'from-coral/40 via-transparent to-transparent',
    'from-gold/40 via-transparent to-transparent',
    'from-teal/40 via-transparent to-transparent',
  ];

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4 border-gold/20 bg-gold/5 px-4 py-1">
            <Sparkles className="h-3.5 w-3.5 mr-2 text-gold" />
            Photo Collection
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Family <span className="rainbow-text">Gallery</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Cherished memories captured through the years
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-md mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gold" />
            <Input
              placeholder="Search photos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-gold/20 focus:border-gold"
            />
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6 text-center">
          <p className="text-muted-foreground">
            <span className="font-semibold rainbow-text">{filteredPhotos.length}</span> {filteredPhotos.length === 1 ? 'photo' : 'photos'}
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="aspect-square bg-muted animate-pulse rounded-xl"
              />
            ))}
          </div>
        ) : filteredPhotos.length === 0 ? (
          <Card className="p-12 text-center max-w-md mx-auto bg-gradient-to-br from-card to-gold/5">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-gold/20 to-coral/20 flex items-center justify-center mx-auto mb-4">
              <Image className="h-8 w-8 text-gold/50" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No Photos Found</h3>
            <p className="text-muted-foreground">
              {searchQuery
                ? 'Try adjusting your search'
                : 'No photos have been uploaded yet'}
            </p>
          </Card>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredPhotos.map((photo, index) => (
              <motion.div
                key={photo.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                className="relative group cursor-pointer"
                onClick={() => setSelectedPhoto(photo)}
              >
                <div className="aspect-square rounded-xl overflow-hidden bg-gradient-to-br from-primary/10 via-coral/10 to-gold/10">
                  <img
                    src={photo.url}
                    alt={photo.caption || 'Family photo'}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                </div>
                
                {/* Overlay */}
                <div className={`absolute inset-0 bg-gradient-to-t ${overlayGradients[index % overlayGradients.length]} via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-xl`}>
                  <div className="absolute bottom-0 left-0 right-0 p-3">
                    {photo.caption && (
                      <p className="text-white text-sm line-clamp-2 drop-shadow-lg">{photo.caption}</p>
                    )}
                    {photo.category && (
                      <Badge className="mt-1 text-xs bg-white/20 backdrop-blur-sm border-white/30 text-white">
                        {photo.category}
                      </Badge>
                    )}
                  </div>
                  <div className="absolute top-2 right-2">
                    <div className="bg-white/20 backdrop-blur-sm rounded-full p-2">
                      <ZoomIn className="h-4 w-4 text-white" />
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}

        {/* Photo Modal */}
        <AnimatePresence>
          {selectedPhoto && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4"
              onClick={() => setSelectedPhoto(null)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                className="relative max-w-4xl w-full"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button
                  className="absolute -top-12 right-0 text-white/70 hover:text-white transition-colors"
                  onClick={() => setSelectedPhoto(null)}
                >
                  <X className="h-8 w-8" />
                </button>

                {/* Image */}
                <div className="rounded-2xl overflow-hidden bg-gradient-to-br from-card to-primary/5 shadow-2xl">
                  <img
                    src={selectedPhoto.url}
                    alt={selectedPhoto.caption || 'Family photo'}
                    className="w-full max-h-[80vh] object-contain"
                  />
                  
                  {/* Caption */}
                  {(selectedPhoto.caption || selectedPhoto.category) && (
                    <div className="p-4 bg-gradient-to-r from-card via-primary/5 to-card">
                      {selectedPhoto.caption && (
                        <p className="text-foreground font-medium">{selectedPhoto.caption}</p>
                      )}
                      {selectedPhoto.category && (
                        <Badge className="mt-2 bg-gradient-to-r from-primary to-teal text-white">
                          {selectedPhoto.category}
                        </Badge>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
