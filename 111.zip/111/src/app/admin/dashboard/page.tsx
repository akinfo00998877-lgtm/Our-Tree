'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  LayoutDashboard,
  Users,
  TreeDeciduous,
  Image,
  LogOut,
  Plus,
  Edit,
  Trash2,
  Upload,
  Search,
  X,
  AlertCircle,
  Check,
  Loader2,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ThemeToggle } from '@/components/theme-toggle';

interface Cousin {
  id: string;
  name: string;
  photo: string | null;
  relation: string;
  description: string | null;
  generation: number;
  order: number;
}

interface GalleryPhoto {
  id: string;
  url: string;
  caption: string | null;
  category: string | null;
}

export default function AdminDashboard() {
  const router = useRouter();
  const [authenticated, setAuthenticated] = useState<boolean | null>(null);
  const [cousins, setCousins] = useState<Cousin[]>([]);
  const [photos, setPhotos] = useState<GalleryPhoto[]>([]);
  const [loading, setLoading] = useState(true);

  // Form states
  const [cousinForm, setCousinForm] = useState({
    name: '',
    photo: '',
    relation: '',
    description: '',
    generation: 1,
    order: 0,
  });
  const [editingCousin, setEditingCousin] = useState<Cousin | null>(null);
  const [photoForm, setPhotoForm] = useState({
    url: '',
    caption: '',
    category: '',
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<{ type: 'cousin' | 'photo'; id: string; name: string } | null>(null);
  const [uploading, setUploading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Check authentication
  useEffect(() => {
    const checkAuth = async () => {
      try {
        const res = await fetch('/api/admin/check');
        const data = await res.json();
        setAuthenticated(data.authenticated);
        if (!data.authenticated) {
          router.push('/admin/login');
        }
      } catch {
        setAuthenticated(false);
        router.push('/admin/login');
      }
    };
    checkAuth();
  }, [router]);

  // Fetch data
  useEffect(() => {
    if (authenticated) {
      fetchData();
    }
  }, [authenticated]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [cousinsRes, photosRes] = await Promise.all([
        fetch('/api/cousins'),
        fetch('/api/gallery'),
      ]);
      const cousinsData = await cousinsRes.json();
      const photosData = await photosRes.json();
      setCousins(cousinsData);
      setPhotos(photosData);
    } catch (error) {
      showMessage('error', 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 3000);
  };

  const handleLogout = async () => {
    await fetch('/api/admin/logout', { method: 'POST' });
    router.push('/');
  };

  // Image upload handler
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: 'cousin' | 'gallery') => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (data.success) {
        if (target === 'cousin') {
          setCousinForm(prev => ({ ...prev, photo: data.url }));
        } else {
          setPhotoForm(prev => ({ ...prev, url: data.url }));
        }
        showMessage('success', 'Image uploaded successfully');
      }
    } catch {
      showMessage('error', 'Failed to upload image');
    } finally {
      setUploading(false);
    }
  };

  // Cousin CRUD
  const handleAddCousin = async () => {
    if (!cousinForm.name || !cousinForm.relation) {
      showMessage('error', 'Name and relation are required');
      return;
    }

    setSaving(true);
    try {
      const res = await fetch('/api/cousins', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cousinForm),
      });

      if (res.ok) {
        const newCousin = await res.json();
        setCousins(prev => [...prev, newCousin]);
        setCousinForm({ name: '', photo: '', relation: '', description: '', generation: 1, order: 0 });
        showMessage('success', 'Cousin added successfully');
      } else {
        showMessage('error', 'Failed to add cousin');
      }
    } catch {
      showMessage('error', 'Failed to add cousin');
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateCousin = async () => {
    if (!editingCousin) return;

    setSaving(true);
    try {
      const res = await fetch(`/api/cousins/${editingCousin.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: cousinForm.name,
          photo: cousinForm.photo,
          relation: cousinForm.relation,
          description: cousinForm.description,
          generation: cousinForm.generation,
          order: cousinForm.order,
        }),
      });

      if (res.ok) {
        const updated = await res.json();
        setCousins(prev => prev.map(c => c.id === updated.id ? updated : c));
        setEditingCousin(null);
        setCousinForm({ name: '', photo: '', relation: '', description: '', generation: 1, order: 0 });
        showMessage('success', 'Cousin updated successfully');
      } else {
        showMessage('error', 'Failed to update cousin');
      }
    } catch {
      showMessage('error', 'Failed to update cousin');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteCousin = async (id: string) => {
    try {
      const res = await fetch(`/api/cousins/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setCousins(prev => prev.filter(c => c.id !== id));
        showMessage('success', 'Cousin deleted successfully');
      }
    } catch {
      showMessage('error', 'Failed to delete cousin');
    } finally {
      setDeleteConfirm(null);
    }
  };

  // Gallery CRUD
  const handleAddPhoto = async () => {
    if (!photoForm.url) {
      showMessage('error', 'Image is required');
      return;
    }

    setSaving(true);
    try {
      const res = await fetch('/api/gallery', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(photoForm),
      });

      if (res.ok) {
        const newPhoto = await res.json();
        setPhotos(prev => [...prev, newPhoto]);
        setPhotoForm({ url: '', caption: '', category: '' });
        showMessage('success', 'Photo added successfully');
      } else {
        showMessage('error', 'Failed to add photo');
      }
    } catch {
      showMessage('error', 'Failed to add photo');
    } finally {
      setSaving(false);
    }
  };

  const handleDeletePhoto = async (id: string) => {
    try {
      const res = await fetch(`/api/gallery/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setPhotos(prev => prev.filter(p => p.id !== id));
        showMessage('success', 'Photo deleted successfully');
      }
    } catch {
      showMessage('error', 'Failed to delete photo');
    } finally {
      setDeleteConfirm(null);
    }
  };

  // Edit cousin handler
  const startEditCousin = (cousin: Cousin) => {
    setEditingCousin(cousin);
    setCousinForm({
      name: cousin.name,
      photo: cousin.photo || '',
      relation: cousin.relation,
      description: cousin.description || '',
      generation: cousin.generation,
      order: cousin.order,
    });
  };

  // Filter cousins
  const filteredCousins = cousins.filter(c =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.relation.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (authenticated === null) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!authenticated) return null;

  return (
    <div className="min-h-screen bg-background">
      {/* Top Navigation */}
      <nav className="bg-card border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <TreeDeciduous className="h-6 w-6 text-primary" />
            <span className="font-bold text-lg">Admin Dashboard</span>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <Button variant="ghost" size="sm" onClick={handleLogout} className="gap-2">
              <LogOut className="h-4 w-4" />
              Logout
            </Button>
          </div>
        </div>
      </nav>

      {/* Message Toast */}
      <AnimatePresence>
        {message && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`fixed top-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 ${
              message.type === 'success' ? 'bg-green-500 text-white' : 'bg-destructive text-destructive-foreground'
            }`}
          >
            {message.type === 'success' ? <Check className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
            {message.text}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto lg:inline-grid">
            <TabsTrigger value="dashboard" className="gap-2">
              <LayoutDashboard className="h-4 w-4" />
              <span className="hidden sm:inline">Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="cousins" className="gap-2">
              <Users className="h-4 w-4" />
              <span className="hidden sm:inline">Cousins</span>
            </TabsTrigger>
            <TabsTrigger value="tree" className="gap-2">
              <TreeDeciduous className="h-4 w-4" />
              <span className="hidden sm:inline">Tree</span>
            </TabsTrigger>
            <TabsTrigger value="gallery" className="gap-2">
              <Image className="h-4 w-4" />
              <span className="hidden sm:inline">Gallery</span>
            </TabsTrigger>
            <TabsTrigger value="add" className="gap-2">
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Add</span>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Total Cousins</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-primary">{cousins.length}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Total Photos</CardTitle>
                  <Image className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold gold-text">{photos.length}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Generations</CardTitle>
                  <TreeDeciduous className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {new Set(cousins.map(c => c.generation)).size}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="flex gap-2">
                  <Button size="sm" onClick={() => document.querySelector('[value="add"]')?.click()}>
                    <Plus className="h-4 w-4 mr-1" />
                    Add New
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <div className="grid gap-6 mt-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Cousins</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {cousins.slice(0, 5).map(cousin => (
                      <div key={cousin.id} className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                          {cousin.photo ? (
                            <img src={cousin.photo} alt={cousin.name} className="w-full h-full object-cover" />
                          ) : (
                            <Users className="h-5 w-5 text-primary/50" />
                          )}
                        </div>
                        <div>
                          <p className="font-medium">{cousin.name}</p>
                          <p className="text-sm text-muted-foreground">{cousin.relation}</p>
                        </div>
                      </div>
                    ))}
                    {cousins.length === 0 && (
                      <p className="text-muted-foreground text-center py-4">No cousins yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Photos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-5 gap-2">
                    {photos.slice(0, 10).map(photo => (
                      <div key={photo.id} className="aspect-square rounded-md overflow-hidden bg-muted">
                        <img src={photo.url} alt="" className="w-full h-full object-cover" />
                      </div>
                    ))}
                    {photos.length === 0 && (
                      <p className="text-muted-foreground text-center py-4 col-span-5">No photos yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Cousins Tab */}
          <TabsContent value="cousins">
            <Card>
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <CardTitle>Manage Cousins</CardTitle>
                    <CardDescription>Add, edit, or remove cousin profiles</CardDescription>
                  </div>
                  <div className="relative w-full sm:w-64">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search cousins..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : filteredCousins.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    {searchQuery ? 'No cousins found' : 'No cousins added yet'}
                  </p>
                ) : (
                  <div className="space-y-2">
                    {filteredCousins.map(cousin => (
                      <div
                        key={cousin.id}
                        className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                            {cousin.photo ? (
                              <img src={cousin.photo} alt={cousin.name} className="w-full h-full object-cover" />
                            ) : (
                              <Users className="h-6 w-6 text-primary/50" />
                            )}
                          </div>
                          <div>
                            <p className="font-medium">{cousin.name}</p>
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary">{cousin.relation}</Badge>
                              <span className="text-xs text-muted-foreground">Gen {cousin.generation}</span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => startEditCousin(cousin)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            className="text-destructive hover:text-destructive"
                            onClick={() => setDeleteConfirm({ type: 'cousin', id: cousin.id, name: cousin.name })}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Tree Tab */}
          <TabsContent value="tree">
            <Card>
              <CardHeader>
                <CardTitle>Manage Family Tree</CardTitle>
                <CardDescription>Organize cousins by generation and order</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : cousins.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">Add cousins first to manage the tree</p>
                ) : (
                  <div className="space-y-6">
                    {Array.from(new Set(cousins.map(c => c.generation))).sort((a, b) => a - b).map(gen => (
                      <div key={gen}>
                        <h3 className="font-semibold mb-3 flex items-center gap-2">
                          <Badge variant="outline">Generation {gen}</Badge>
                        </h3>
                        <div className="space-y-2">
                          {cousins
                            .filter(c => c.generation === gen)
                            .sort((a, b) => a.order - b.order)
                            .map(cousin => (
                              <div
                                key={cousin.id}
                                className="flex items-center justify-between p-3 rounded-lg border bg-card"
                              >
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center overflow-hidden">
                                    {cousin.photo ? (
                                      <img src={cousin.photo} alt={cousin.name} className="w-full h-full object-cover" />
                                    ) : (
                                      <Users className="h-5 w-5 text-primary/50" />
                                    )}
                                  </div>
                                  <div>
                                    <p className="font-medium">{cousin.name}</p>
                                    <p className="text-sm text-muted-foreground">{cousin.relation}</p>
                                  </div>
                                </div>
                                <div className="flex items-center gap-2">
                                  <Label className="text-sm">Order:</Label>
                                  <Input
                                    type="number"
                                    className="w-20"
                                    value={cousin.order}
                                    onChange={async (e) => {
                                      const newOrder = parseInt(e.target.value) || 0;
                                      try {
                                        await fetch(`/api/cousins/${cousin.id}`, {
                                          method: 'PUT',
                                          headers: { 'Content-Type': 'application/json' },
                                          body: JSON.stringify({ ...cousin, order: newOrder }),
                                        });
                                        setCousins(prev => prev.map(c => 
                                          c.id === cousin.id ? { ...c, order: newOrder } : c
                                        ));
                                      } catch {
                                        showMessage('error', 'Failed to update order');
                                      }
                                    }}
                                  />
                                  <Button
                                    size="sm"
                                    variant="ghost"
                                    onClick={() => startEditCousin(cousin)}
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Gallery Tab */}
          <TabsContent value="gallery">
            <Card>
              <CardHeader>
                <CardTitle>Manage Gallery</CardTitle>
                <CardDescription>Upload and manage family photos</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin" />
                  </div>
                ) : photos.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">No photos in gallery</p>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    {photos.map(photo => (
                      <div key={photo.id} className="relative group">
                        <div className="aspect-square rounded-lg overflow-hidden bg-muted">
                          <img src={photo.url} alt={photo.caption || ''} className="w-full h-full object-cover" />
                        </div>
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => setDeleteConfirm({ type: 'photo', id: photo.id, name: photo.caption || 'this photo' })}
                          >
                            <Trash2 className="h-4 w-4 mr-1" />
                            Delete
                          </Button>
                        </div>
                        {photo.caption && (
                          <p className="mt-2 text-sm truncate">{photo.caption}</p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Add Tab */}
          <TabsContent value="add">
            <div className="grid gap-6 md:grid-cols-2">
              {/* Add Cousin Form */}
              <Card>
                <CardHeader>
                  <CardTitle>{editingCousin ? 'Edit Cousin' : 'Add New Cousin'}</CardTitle>
                  <CardDescription>
                    {editingCousin ? 'Update cousin information' : 'Add a new family member to the tree'}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name *</Label>
                    <Input
                      id="name"
                      value={cousinForm.name}
                      onChange={(e) => setCousinForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter name"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Photo</Label>
                    <div className="flex items-center gap-4">
                      <div className="w-20 h-20 rounded-lg bg-muted flex items-center justify-center overflow-hidden">
                        {cousinForm.photo ? (
                          <img src={cousinForm.photo} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <Users className="h-8 w-8 text-muted-foreground" />
                        )}
                      </div>
                      <div>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => handleImageUpload(e, 'cousin')}
                          className="hidden"
                          id="cousin-photo"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => document.getElementById('cousin-photo')?.click()}
                          disabled={uploading}
                        >
                          {uploading ? (
                            <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          ) : (
                            <Upload className="h-4 w-4 mr-2" />
                          )}
                          Upload Photo
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="relation">Relation *</Label>
                    <Input
                      id="relation"
                      value={cousinForm.relation}
                      onChange={(e) => setCousinForm(prev => ({ ...prev, relation: e.target.value }))}
                      placeholder="e.g., Cousin, Uncle, Aunt"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={cousinForm.description}
                      onChange={(e) => setCousinForm(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="A short description..."
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="generation">Generation</Label>
                      <Input
                        id="generation"
                        type="number"
                        min="1"
                        value={cousinForm.generation}
                        onChange={(e) => setCousinForm(prev => ({ ...prev, generation: parseInt(e.target.value) || 1 }))}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="order">Order</Label>
                      <Input
                        id="order"
                        type="number"
                        min="0"
                        value={cousinForm.order}
                        onChange={(e) => setCousinForm(prev => ({ ...prev, order: parseInt(e.target.value) || 0 }))}
                      />
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button onClick={editingCousin ? handleUpdateCousin : handleAddCousin} disabled={saving}>
                      {saving ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : (
                        <Plus className="h-4 w-4 mr-2" />
                      )}
                      {editingCousin ? 'Update' : 'Add'} Cousin
                    </Button>
                    {editingCousin && (
                      <Button
                        variant="outline"
                        onClick={() => {
                          setEditingCousin(null);
                          setCousinForm({ name: '', photo: '', relation: '', description: '', generation: 1, order: 0 });
                        }}
                      >
                        Cancel
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Add Photo Form */}
              <Card>
                <CardHeader>
                  <CardTitle>Add Photo to Gallery</CardTitle>
                  <CardDescription>Upload a new photo to the family gallery</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label>Photo</Label>
                    <div className="flex flex-col items-center gap-4">
                      <div className="w-full aspect-video rounded-lg bg-muted flex items-center justify-center overflow-hidden">
                        {photoForm.url ? (
                          <img src={photoForm.url} alt="" className="w-full h-full object-cover" />
                        ) : (
                          <Image className="h-12 w-12 text-muted-foreground" />
                        )}
                      </div>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImageUpload(e, 'gallery')}
                        className="hidden"
                        id="gallery-photo"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById('gallery-photo')?.click()}
                        disabled={uploading}
                      >
                        {uploading ? (
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                        ) : (
                          <Upload className="h-4 w-4 mr-2" />
                        )}
                        Upload Photo
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="caption">Caption</Label>
                    <Input
                      id="caption"
                      value={photoForm.caption}
                      onChange={(e) => setPhotoForm(prev => ({ ...prev, caption: e.target.value }))}
                      placeholder="Describe this photo"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Input
                      id="category"
                      value={photoForm.category}
                      onChange={(e) => setPhotoForm(prev => ({ ...prev, category: e.target.value }))}
                      placeholder="e.g., Family Gathering, Wedding"
                    />
                  </div>

                  <Button onClick={handleAddPhoto} disabled={saving || !photoForm.url}>
                    {saving ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Plus className="h-4 w-4 mr-2" />
                    )}
                    Add to Gallery
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!deleteConfirm} onOpenChange={() => setDeleteConfirm(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Delete</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {deleteConfirm?.name}? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteConfirm(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => {
                if (deleteConfirm?.type === 'cousin') {
                  handleDeleteCousin(deleteConfirm.id);
                } else if (deleteConfirm?.type === 'photo') {
                  handleDeletePhoto(deleteConfirm.id);
                }
              }}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
