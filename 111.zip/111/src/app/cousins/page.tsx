'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Users, Search, Grid, List, Sparkles } from 'lucide-react';
import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

interface Cousin {
  id: string;
  name: string;
  photo: string | null;
  relation: string;
  description: string | null;
}

export default function CousinsPage() {
  const [cousins, setCousins] = useState<Cousin[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedRelation, setSelectedRelation] = useState<string | null>(null);

  useEffect(() => {
    const fetchCousins = async () => {
      try {
        const res = await fetch('/api/cousins');
        const data = await res.json();
        setCousins(data);
      } catch (error) {
        console.error('Error fetching cousins:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchCousins();
  }, []);

  // Get unique relations for filter
  const relations = [...new Set(cousins.map(c => c.relation))];

  // Filter cousins
  const filteredCousins = cousins.filter(cousin => {
    const matchesSearch = cousin.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cousin.relation.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesRelation = !selectedRelation || cousin.relation === selectedRelation;
    return matchesSearch && matchesRelation;
  });

  const cardGradients = [
    'from-primary/20 via-coral/10 to-gold/20',
    'from-coral/20 via-gold/10 to-primary/20',
    'from-gold/20 via-primary/10 to-coral/20',
    'from-teal/20 via-primary/10 to-gold/20',
  ];

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4 border-coral/20 bg-coral/5 px-4 py-1">
            <Sparkles className="h-3.5 w-3.5 mr-2 text-gold" />
            Family Members
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Meet the <span className="rainbow-text">Cousins</span>
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Get to know each member of our wonderful family
          </p>
        </div>

        {/* Search and Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-primary" />
            <Input
              placeholder="Search cousins..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 border-primary/20 focus:border-primary"
            />
          </div>
          
          <div className="flex items-center gap-2 flex-wrap">
            {/* Relation Filter */}
            <div className="flex items-center gap-1 flex-wrap">
              <Button
                variant={selectedRelation === null ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedRelation(null)}
                className={selectedRelation === null ? 'bg-gradient-to-r from-primary to-teal text-white' : ''}
              >
                All
              </Button>
              {relations.map(relation => (
                <Button
                  key={relation}
                  variant={selectedRelation === relation ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedRelation(relation)}
                  className={selectedRelation === relation ? 'bg-gradient-to-r from-coral to-gold text-white' : ''}
                >
                  {relation}
                </Button>
              ))}
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center border border-primary/20 rounded-lg overflow-hidden">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="icon"
                className={`rounded-none ${viewMode === 'grid' ? 'bg-gradient-to-r from-primary to-teal text-white' : ''}`}
                onClick={() => setViewMode('grid')}
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="icon"
                className={`rounded-none ${viewMode === 'list' ? 'bg-gradient-to-r from-primary to-teal text-white' : ''}`}
                onClick={() => setViewMode('list')}
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-muted-foreground">
            Showing <span className="font-semibold text-primary">{filteredCousins.length}</span> of {cousins.length} cousins
          </p>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <Card key={i} className="overflow-hidden">
                <div className="aspect-square bg-muted animate-pulse" />
                <CardContent className="p-4">
                  <div className="h-4 bg-muted rounded animate-pulse mb-2" />
                  <div className="h-3 bg-muted rounded animate-pulse w-1/2" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : filteredCousins.length === 0 ? (
          <Card className="p-12 text-center max-w-md mx-auto bg-gradient-to-br from-card to-primary/5">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary/20 to-coral/20 flex items-center justify-center mx-auto mb-4">
              <Users className="h-8 w-8 text-primary/50" />
            </div>
            <h3 className="text-xl font-semibold mb-2">No Cousins Found</h3>
            <p className="text-muted-foreground">
              {searchQuery || selectedRelation
                ? 'Try adjusting your search or filters'
                : 'No cousins have been added yet'}
            </p>
          </Card>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredCousins.map((cousin, index) => (
              <motion.div
                key={cousin.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="overflow-hidden card-hover h-full group">
                  <div className={`aspect-square bg-gradient-to-br ${cardGradients[index % cardGradients.length]} flex items-center justify-center overflow-hidden relative`}>
                    {cousin.photo ? (
                      <img
                        src={cousin.photo}
                        alt={cousin.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      />
                    ) : (
                      <div className="w-20 h-20 rounded-full bg-white/50 backdrop-blur-sm flex items-center justify-center">
                        <Users className="h-10 w-10 text-primary/40" />
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-primary/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg truncate group-hover:text-primary transition-colors">{cousin.name}</CardTitle>
                  </CardHeader>
                  <CardContent className="bg-gradient-to-b from-card to-primary/5">
                    <Badge className="bg-gradient-to-r from-primary to-teal text-white text-xs">
                      {cousin.relation}
                    </Badge>
                    {cousin.description && (
                      <p className="text-sm text-muted-foreground line-clamp-2 mt-2">
                        {cousin.description}
                      </p>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredCousins.map((cousin, index) => (
              <motion.div
                key={cousin.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className="overflow-hidden card-hover group">
                  <div className="flex">
                    <div className={`w-24 h-24 md:w-32 md:h-32 bg-gradient-to-br ${cardGradients[index % cardGradients.length]} flex items-center justify-center overflow-hidden flex-shrink-0`}>
                      {cousin.photo ? (
                        <img
                          src={cousin.photo}
                          alt={cousin.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        />
                      ) : (
                        <Users className="h-10 w-10 text-primary/40" />
                      )}
                    </div>
                    <div className="flex-1 p-4 bg-gradient-to-r from-card to-primary/5">
                      <h3 className="font-semibold text-lg group-hover:text-primary transition-colors">{cousin.name}</h3>
                      <Badge className="bg-gradient-to-r from-coral to-gold text-white mt-1">
                        {cousin.relation}
                      </Badge>
                      {cousin.description && (
                        <p className="text-sm text-muted-foreground line-clamp-2 mt-2">
                          {cousin.description}
                        </p>
                      )}
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
