import { db } from './db';
import { cookies } from 'next/headers';
import { randomBytes } from 'crypto';

const ADMIN_USERNAME = 'sit Khan';
const ADMIN_PASSWORD = '8660';
const SESSION_DURATION = 24 * 60 * 60 * 1000; // 24 hours

export async function createSession(): Promise<string> {
  const token = randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + SESSION_DURATION);
  
  await db.adminSession.create({
    data: {
      token,
      expiresAt,
    },
  });
  
  return token;
}

export async function validateSession(token: string): Promise<boolean> {
  if (!token) return false;
  
  const session = await db.adminSession.findUnique({
    where: { token },
  });
  
  if (!session) return false;
  
  if (new Date() > session.expiresAt) {
    await db.adminSession.delete({ where: { token } });
    return false;
  }
  
  return true;
}

export async function deleteSession(token: string): Promise<void> {
  if (token) {
    await db.adminSession.deleteMany({ where: { token } });
  }
}

export async function verifyCredentials(username: string, password: string): Promise<boolean> {
  return username === ADMIN_USERNAME && password === ADMIN_PASSWORD;
}

export async function getSessionToken(): Promise<string | undefined> {
  const cookieStore = await cookies();
  return cookieStore.get('admin_token')?.value;
}

export async function isAuthenticated(): Promise<boolean> {
  const token = await getSessionToken();
  if (!token) return false;
  return validateSession(token);
}
