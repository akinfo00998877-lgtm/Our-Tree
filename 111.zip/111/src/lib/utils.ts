import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatRelation(relation: string): string {
  return relation.charAt(0).toUpperCase() + relation.slice(1);
}
